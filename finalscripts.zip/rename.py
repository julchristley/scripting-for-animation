import maya.cmds as cmds

def rename(name, num, node_type) :
    objects = cmds.ls(selection=True)

    temp = name.count("#")
    old_name = name.replace("#" * temp, "{:0" + str(temp) + "d}")

    new_names = []

    for i, obj in enumerate(objects, start=num) :
        name_full = old_name.format(i)
        final_name = f"{name_full}_{node_type}"
        new_name = cmds.rename(obj, final_name)
        new_names.append(new_name)